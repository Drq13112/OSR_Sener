#ifndef SM_OPTIONS_H
#define SM_OPTIONS_H

#include <options/options.h>
#include "csm/csm_all.h"

void sm_options(struct sm_params*p, struct option*ops);

#endif
