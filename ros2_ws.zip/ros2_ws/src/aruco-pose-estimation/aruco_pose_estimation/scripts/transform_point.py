import numpy as np
import tf_transformations

def transform_point_to_map(robot_pos_map, robot_quat_map, point_pos_bl):
    # Convert robot's quaternion and position to a transformation matrix
    T_robot_map = tf_transformations.quaternion_matrix(robot_quat_map)
    T_robot_map[:3, 3] = robot_pos_map

    # Convert point position in base_link frame to homogeneous coordinates
    point_pos_bl_homogeneous = np.array([*point_pos_bl, 1.0])

    # Transform point from base_link to map frame
    point_pos_map_homogeneous = np.dot(T_robot_map, point_pos_bl_homogeneous)
    point_pos_map = point_pos_map_homogeneous[:3]

    return point_pos_map

# Example usage
robot_pos_map = [x_robot_map, y_robot_map, z_robot_map]
robot_quat_map = [qx_robot_map, qy_robot_map, qz_robot_map, qw_robot_map]
point_pos_bl = [x_point_bl, y_point_bl, z_point_bl]

point_pos_map = transform_point_to_map(robot_pos_map, robot_quat_map, point_pos_bl)

print("Point Position in Map Frame: ", point_pos_map)
