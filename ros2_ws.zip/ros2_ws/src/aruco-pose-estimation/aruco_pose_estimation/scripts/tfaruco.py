#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose
from geometry_msgs.msg import PoseArray, TransformStamped
from tf2_ros import TransformBroadcaster
from tf_transformations import quaternion_multiply, quaternion_from_euler

class ArucoTfBroadcaster(Node):
    def __init__(self):
        super().__init__('aruco_tf_broadcaster')
        
        self.subscription = self.create_subscription(
            PoseArray,
            'aruco/poses',
            self.pose_array_callback,
            10)
        self.br = TransformBroadcaster(self)

    def pose_array_callback(self, msg):
    
        for i, pose in enumerate(msg.poses):
            t = TransformStamped()
            t.header.stamp = self.get_clock().now().to_msg()
            t.header.frame_id = f"b{i+1}" # El frame de referencia, ajústalo según tu necesidad
            t.child_frame_id = "base_link"  # Puedes cambiar el nombre del frame según tus necesidades

            t.transform.translation.x = pose.position.x
            t.transform.translation.y = pose.position.y
            t.transform.translation.z = pose.position.z
            # Obtener la orientación original del marcador ArUco
            original_orientation = [
                pose.orientation.x,
                pose.orientation.y,
                pose.orientation.z,
                pose.orientation.w
            ]

            # Crear una rotación de 90 grados en el eje Y
            rotation_90_y = quaternion_from_euler(0, 1.5708, 0)  # 90 grados en radianes

            # Combinar las dos rotaciones
            new_orientation = quaternion_multiply(rotation_90_y, original_orientation)

            t.transform.rotation.x = new_orientation[0]
            t.transform.rotation.y = new_orientation[1]
            t.transform.rotation.z = new_orientation[2]
            t.transform.rotation.w = new_orientation[3]

            self.br.sendTransform(t)
            print("publicando tf aruco")

def main(args=None):
    rclpy.init(args=args)
    node = ArucoTfBroadcaster()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

