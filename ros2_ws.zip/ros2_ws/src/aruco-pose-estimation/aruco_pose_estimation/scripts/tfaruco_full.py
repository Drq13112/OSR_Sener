#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose
from geometry_msgs.msg import PoseArray, TransformStamped, Twist, PoseStamped
from tf2_ros import TransformBroadcaster
from tf_transformations import quaternion_multiply, quaternion_from_euler, euler_from_quaternion
import math
from aruco_interfaces.msg import ArucoMarkers
import time

from tf2_ros import TransformException 
from tf2_ros.buffer import Buffer
 
# Easy way to request and receive coordinate frame transform information
from tf2_ros.transform_listener import TransformListener 

class ArucoTfBroadcaster(Node):
    def __init__(self):
        super().__init__('aruco_tf_broadcaster')
        
        self.subscription = self.create_subscription(
            PoseArray,
            'aruco/poses',
            self.pose_array_callback,
            1)
        self.subscription_id = self.create_subscription(
            ArucoMarkers,
            'aruco/markers',
            self.id_callback,
            1)
        self.br = TransformBroadcaster(self)

        timer_period = 0.05  # seconds
        self.timer = self.create_timer(timer_period, self.tf_timer)

        timer_period = 1.0  # seconds
        self.timer = self.create_timer(timer_period, self.publish_destination)

        timer_period = 1.0  # seconds
        self.timer = self.create_timer(timer_period, self.nav_point)

        self.tf_buffer = Buffer()
        self.contador_puntos = 0
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.publisher_goal = self.create_publisher(
      PoseStamped, 
      '/goal_pose', 
      1)
        
        self.p1_x = None
        self.p1_y = None
        self.p2_x = None
        self.p2_y = None
        self.p3_x = None
        self.p3_y = None
        self.p4_x = None
        self.p4_y = None

        self.id=None

    def id_callback(self,msg):
        self.id=msg.marker_ids[0]


    def pose_array_callback(self, msg):
        """
        for i, pose in enumerate(msg.poses):
            t = TransformStamped()
            t.header.stamp = self.get_clock().now().to_msg()
            t.header.frame_id = 'base_link_aux' # El frame de referencia
            if self.id is not None:
                if self.id==30:
                    t.child_frame_id = 'b1'  
                elif self.id==31:
                    t.child_frame_id = 'b2'  
                elif self.id==32:
                    t.child_frame_id = 'b3'  
                elif self.id==33:
                    t.child_frame_id = 'b4'  
        """

        pose = msg.poses[0]
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'base_link_aux' # El frame de referencia
        if self.id is not None:
            if self.id==30:
                t.child_frame_id = 'b1'  
            elif self.id==31:
                t.child_frame_id = 'b2'  
            elif self.id==32:
                t.child_frame_id = 'b3'  
            elif self.id==33:
                t.child_frame_id = 'b4'
        

        t.transform.translation.x = -pose.position.z
        t.transform.translation.y = -pose.position.x
        t.transform.translation.z = pose.position.y
        
        # Obtener la orientacion original del marcador ArUco
        

        original_orientation = [
            pose.orientation.x,
            pose.orientation.y,
            pose.orientation.z,
            pose.orientation.w
        ]

        euler_original=euler_from_quaternion(original_orientation)

        orientation_fixed=quaternion_from_euler(0.0,0.0,euler_original[2])
        # Crear una rotación de 90 grados en el eje Y
        rotation_90_y = quaternion_from_euler(0, 0.0, math.pi)  # 90 grados en radianes

        # Combinar las dos rotaciones
        new_orientation = quaternion_multiply(rotation_90_y, original_orientation)
        new_orientation_fixed = quaternion_multiply(rotation_90_y, original_orientation)

        #t.transform.rotation.x = new_orientation[0]
        #t.transform.rotation.y = new_orientation[1]
        #t.transform.rotation.z = new_orientation[2]
        #t.transform.rotation.w = new_orientation[3]

        t.transform.rotation.x = orientation_fixed[0]
        t.transform.rotation.y = orientation_fixed[1]
        t.transform.rotation.z = orientation_fixed[2]
        t.transform.rotation.w = orientation_fixed[3]

        self.br.sendTransform(t)
        #print("publicando tf aruco")

    def publish_tf(self,x,y,z,yaw,frame,child):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = frame # El frame de referencia, ajústalo según tu necesidad
        t.child_frame_id = child  # Puedes cambiar el nombre del frame según tus necesidades
        t.transform.translation.x = x
        t.transform.translation.y = y
        t.transform.translation.z = z

        # Combinar las dos rotacionesrotation[0]
        rotation = quaternion_from_euler(0,0, yaw)  # 90 grados en radianes

        t.transform.rotation.x = rotation[0]
        t.transform.rotation.y = rotation[1]
        t.transform.rotation.z = rotation[2]
        t.transform.rotation.w = rotation[3]
        self.br.sendTransform(t)

    def tf_timer(self):

        punto1_x=2.0
        punto1_y=2.0

        punto2_x=6.0
        punto2_y=5.0

        punto3_x=3.5
        punto3_y=3.5

        punto4_x=1.0
        punto4_y=6.0

        if self.id is not None:
            if self.id==30:
                self.publish_tf(0.0,3.5,0.0,0.0,'map_sener','b3')
                self.publish_tf(3.5,7.0,0.0,-1.57,'map_sener','b2')
                self.publish_tf(7.0,3.5,0.0,math.pi,'b1','map_sener')
                self.publish_tf(3.5,0.0,0.0,1.57,'map_sener','b4')
                self.publish_tf(punto1_x,punto1_y,0.0,0.0,'map_sener','punto1')
                self.publish_tf(punto2_x,punto2_y,0.0,0.0,'map_sener','punto2') 
                self.publish_tf(punto3_x,punto3_y,0.0,0.0,'map_sener','punto3')
                self.publish_tf(punto4_x,punto4_y,0.0,0.0,'map_sener','punto4')
            elif self.id==31:
                self.publish_tf(0.0,3.5,0.0,0.0,'map_sener','b3')
                self.publish_tf(7.0,-3.5,0.0,1.57,'b2','map_sener')
                self.publish_tf(7.0,3.5,0.0,math.pi,'map_sener','b1')
                self.publish_tf(3.5,0.0,0.0,1.57,'map_sener','b4')
                self.publish_tf(punto1_x,punto1_y,0.0,0.0,'map_sener','punto1')
                self.publish_tf(punto2_x,punto2_y,0.0,0.0,'map_sener','punto2') 
                self.publish_tf(punto3_x,punto3_y,0.0,0.0,'map_sener','punto3')
                self.publish_tf(punto4_x,punto4_y,0.0,0.0,'map_sener','punto4')
            elif self.id==32:
                self.publish_tf(0.0,-3.5,0.0,0.0,'b3','map_sener')
                self.publish_tf(3.5,7.0,0.0,-1.57,'map_sener','b2')
                self.publish_tf(7.0,3.5,0.0,math.pi,'map_sener','b1')
                self.publish_tf(3.5,0.0,0.0,1.57,'map_sener','b4')
                self.publish_tf(punto1_x,punto1_y,0.0,0.0,'map_sener','punto1')
                self.publish_tf(punto2_x,punto2_y,0.0,0.0,'map_sener','punto2') 
                self.publish_tf(punto3_x,punto3_y,0.0,0.0,'map_sener','punto3')
                self.publish_tf(punto4_x,punto4_y,0.0,0.0,'map_sener','punto4')
            elif self.id==33:
                self.publish_tf(0.0,3.5,0.0,0.0,'map_sener','b3')
                self.publish_tf(3.5,7.0,0.0,-1.57,'map_sener','b2')
                self.publish_tf(7.0,3.5,0.0,math.pi,'map_sener','b1')
                self.publish_tf(0.0,3.5,0.0,-1.57,'b4','map_sener')
                self.publish_tf(punto1_x,punto1_y,0.0,0.0,'map_sener','punto1')
                self.publish_tf(punto2_x,punto2_y,0.0,0.0,'map_sener','punto2') 
                self.publish_tf(punto3_x,punto3_y,0.0,0.0,'map_sener','punto3')
                self.publish_tf(punto4_x,punto4_y,0.0,0.0,'map_sener','punto4')


            #para el giro que no sabemos a que se debe
            self.publish_tf(0.0,0.0,0.0,math.pi,'base_link','base_link_aux')
    

    
    def publish_destination(self):
        try:
          now = rclpy.time.Time()
          trans_p1 = self.tf_buffer.lookup_transform(
                      'map',
                      'punto1',
                      now)
          trans_p2 = self.tf_buffer.lookup_transform(
                      'map',
                      'punto2',
                      now)
          trans_p3 = self.tf_buffer.lookup_transform(
                      'map',
                      'punto3',
                      now)
          trans_p4 = self.tf_buffer.lookup_transform(
                      'map',
                      'punto4',
                      now)
        except TransformException as ex:
          self.get_logger().info(
            f'Could not transform points')
          return
        
        
        self.p1_x = trans_p1.transform.translation.x
        self.p1_y = trans_p1.transform.translation.y
        self.p2_x = trans_p2.transform.translation.x
        self.p2_y = trans_p2.transform.translation.y
        self.p3_x = trans_p3.transform.translation.x
        self.p3_y = trans_p3.transform.translation.y
        self.p4_x = trans_p4.transform.translation.x
        self.p4_y = trans_p4.transform.translation.y

        print('punto 1: ', self.p1_x, self.p1_y)
        print('punto 2: ', self.p2_x, self.p2_y)
        print('punto 3: ', self.p3_x, self.p3_y)
        print('punto 4: ', self.p4_x, self.p4_y)


    def nav_point(self):
        if self.p1_x is not None:
            nav_points=[[self.p1_x,self.p1_y],[self.p2_x,self.p2_y],[self.p3_x,self.p3_y],[self.p4_x,self.p4_y]]
            try:
                now = rclpy.time.Time()
                current_pose = self.tf_buffer.lookup_transform(
                            'map',
                            'base_link',
                            now)
                
                point = nav_points[self.contador_puntos]
                distance = self.euclidean_distance(point, current_pose.transform.translation)
                if distance > 0.1:
                    self.pub_movebase(point[0],point[1])
                else:
                    self.contador_puntos = self.contador_puntos+1
                    time.sleep(5)

            except TransformException as ex:
                self.get_logger().info(
                    f'Could not transform points')
                return
            
    def euclidean_distance(self, pos1, pos2):
        return abs(math.sqrt((pos1[0] - pos2.x) ** 2 + (pos1[0] - pos2.y) ** 2))
        

    def pub_movebase(self,goal_x,goal_y):
        if self.p1_x is not None:
            msg = PoseStamped()
            msg.header.frame_id='map'
            msg.pose.position.x=goal_x
            msg.pose.position.y=goal_y
            msg.pose.position.z=0.0
            msg.pose.orientation.x=0.0
            msg.pose.orientation.y=0.0
            msg.pose.orientation.z=0.0
            msg.pose.orientation.w=1.0

            self.publisher_goal.publish(msg)

        else:
            print("Something is failing, but im fine")
                  

def main(args=None):
    rclpy.init(args=args)
    node = ArucoTfBroadcaster()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

