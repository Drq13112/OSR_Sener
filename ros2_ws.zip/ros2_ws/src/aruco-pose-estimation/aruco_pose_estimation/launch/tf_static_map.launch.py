from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():

    ld = LaunchDescription()
    
    node1 =  Node(package = "tf2_ros",  executable = "static_transform_publisher", name='aruco3', arguments = ['0','3.5','0','0', '0', '0', 'map_sener', 'b3'],                )
    node2 =  Node(package = "tf2_ros",  executable = "static_transform_publisher", name='aruco2', arguments = ['3.5','7.0','0','0', '0', '0', 'map_sener', 'b2'],                )
    node3 =  Node(package = "tf2_ros",  executable = "static_transform_publisher", name='aruco1', arguments = ['7.0','3.5','0','0', '0', '0', 'map_sener', 'b1'],                )
    node4 =  Node(package = "tf2_ros",  executable = "static_transform_publisher", name='aruco4', arguments = ['3.5','0.0','0','0', '0', '0', 'map_sener', 'b4'],                )
    nodep1 = Node(package = "tf2_ros",  executable = "static_transform_publisher", name='punto1', arguments = ['1.0','1.0','0','0', '0', '0', 'map_sener', 'punto1'],                )
    nodep2 = Node(package = "tf2_ros",  executable = "static_transform_publisher", name='punto2', arguments = ['4.0','1.0','0','0', '0', '0', 'map_sener', 'punto2'], )
    nodep3 = Node(package = "tf2_ros",  executable = "static_transform_publisher", name='punto3', arguments = ['1.0','6.0','0','0', '0', '0', 'map_sener', 'punto3'],)
    nodep4 = Node(package = "tf2_ros",  executable = "static_transform_publisher", name='punto4', arguments = ['6.0','5.0','0','0', '0', '0', 'map_sener', 'punto4'],)
    
    
    ld.add_action(node1)
    ld.add_action(node2)
    ld.add_action(node3)
    ld.add_action(node4)

    ld.add_action(nodep1)
    ld.add_action(nodep2)
    ld.add_action(nodep3)
    ld.add_action(nodep4)


    return ld